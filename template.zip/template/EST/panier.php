<?php
    session_start();
    include 'abbreviations.php';
    $rows=panier($_SESSION['ID']);
    $prodid = isset($_GET['delete'])&&is_numeric($_GET['delete']) ? intval($_GET['delete']) : 0;
    $stmt=$connect->prepare("DELETE FROM panier WHERE id_pr=?");
    $stmt->execute(array($prodid));
?>
<section class="jumbotron text-center">
    <div class="container">
        <h1 class="jumbotron-heading">Panier</h1>
     </div>
</section>

<div class="container mb-4 panier">
    <div class="row">
        <div class="col-12">
            <div class="table-responsive">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th scope="col">Image</th>
                            <th scope="col">Produit</th>
                            <th scope="col" class="text-right">Prix</th>
                            <th> </th>
                        </tr>
                    </thead>
                    <tbody>
<?php                   foreach($rows as $row){
                            
                        
?>                        <tr>
                            <td><img src="<?php echo $row['img_pr']; ?>"/> </td>
                            <td class=" font-weight-bold"><?php echo $row['nom_pr']; ?></td>
                            <td class="text-right font-weight-bold"><?php echo $row['prix']; ?> DH</td>
                            <td class="text-right"><a href="?delete=<?php echo $row['id_pr'] ?>" class="confirmation btn btn-sm btn-danger"><i class="fa fa-trash"></i> </a> </td>
                        </tr>
<?php                         }?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php
    include $templates.'footer.php';
?>