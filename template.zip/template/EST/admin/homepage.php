<?php

    session_start();
    if(isset($_SESSION['log'])){
        echo 'Bienvenue '.$_SESSION['log'];        
    }else{
        header('location: index.php');
        exit(); 
    }