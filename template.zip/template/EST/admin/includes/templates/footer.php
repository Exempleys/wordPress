
    
    <footer class="jumbotron text-center mt-auto">&copy; Copyright 2020 - All rights reserved</footer>
    <script src='<?php echo $js; ?>jquery-3.5.1.js'></script>
    <script src='<?php echo $js; ?>bootstrap.min.js'></script>
    <script src='<?php echo $js; ?>backend.js'></script>
</body>
</html>