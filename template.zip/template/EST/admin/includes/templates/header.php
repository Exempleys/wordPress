<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="shortcut icon" href='<?php echo $img; ?>sale.png' />
    <link rel="stylesheet" href='<?php echo $css; ?>bootstrap.min.css'>
    <link rel="stylesheet" href='<?php echo $css; ?>font-awesome.min.css'>
    <link rel="stylesheet" href='<?php echo $css; ?>backend.css'>
    <title><?php Titles() ?></title>
</head>
<body class="d-flex flex-column min-vh-100">
    