
    
    <footer class="jumbotron text-center mt-auto bg-dark text-white">&copy; Copyright 2020 - All rights reserved</footer>
    <script src='<?php echo $js; ?>jquery-3.5.1.js'></script>
    <script src='<?php echo $js; ?>bootstrap.min.js'></script>
    <script src='<?php echo $js; ?>frontend.js'></script>
</body>
</html>